# BRI QRIS Dynamic MPM — Private Backend + Web UI

Web sederhana untuk:
- input nominal
- klik Continue
- backend meminta QRIS Dynamic MPM ke BRIAPI Sandbox
- QR ditampilkan
- tombol Refresh mengecek status pembayaran melalui Inquiry Payment
- credential BRIAPI hanya dibaca dari environment variable, bukan dari frontend

## Penting tentang GitHub

PHP tidak berjalan di GitHub Pages. Gunakan GitHub sebagai repository, lalu deploy folder ini ke hosting/server PHP.

Agar credential dan source backend tidak terbuka:
1. Jadikan repository **Private** jika backend ikut disimpan di GitHub.
2. Jangan commit `.env`, Client Secret, private key, atau credential.
3. Untuk repository public, taruh hanya folder `public/` dan dokumentasi; backend simpan di private server/repository.
4. `config.php` tidak menyimpan credential.

## Konfigurasi

Set environment variable berikut di server:

BRI_CLIENT_ID=...
BRI_CLIENT_SECRET=...
BRI_PARTNER_ID=...
BRI_CHANNEL_ID=...
BRI_MERCHANT_ID=...
BRI_TERMINAL_ID=...

Opsional:
BRI_BASE_URL=https://sandbox.partner.api.bri.co.id

Untuk keamanan, jangan pernah menaruh Client Secret di JavaScript.

## Struktur

public/
  index.php
  api/
    generate.php
    status.php
    _bootstrap.php
storage/
  orders/

`storage/` harus berada di luar web root bila memungkinkan. Jika hosting memaksa berada di dalam public_html, blok akses HTTP ke `/storage`.

## Alur

POST `public/api/generate.php`
-> GET token
-> POST `/snap/v1.1/qr/qr-mpm-generate`
-> simpan referenceNo + partnerReferenceNo
-> kirim `qrContent` ke browser

POST `public/api/status.php`
-> POST `/snap/v1.1/qr/qr-mpm-query`
-> kirim status pembayaran

Dokumentasi BRIAPI:
https://developers.bri.co.id/id/snap-bi/qris-merchant-presented-mode-mpm-dinamis-v1.1
