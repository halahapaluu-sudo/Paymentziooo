<?php
declare(strict_types=1);
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>QRIS Payment</title>
  <meta name="description" content="Generate QRIS pembayaran">
  <style>
    *{box-sizing:border-box}
    body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#f4f7fb;color:#10233f}
    .wrap{min-height:100vh;display:grid;place-items:center;padding:24px}
    .card{width:min(430px,100%);background:#fff;border-radius:22px;padding:28px;box-shadow:0 16px 50px rgba(16,35,63,.12)}
    h1{margin:0 0 8px;font-size:26px}
    .muted{color:#6c7a8e;margin:0 0 24px}
    label{display:block;font-weight:700;margin-bottom:8px}
    input{width:100%;padding:15px;border:1px solid #d7deea;border-radius:12px;font-size:18px;outline:none}
    input:focus{border-color:#1f6feb;box-shadow:0 0 0 3px rgba(31,111,235,.12)}
    button{width:100%;border:0;border-radius:12px;padding:15px;font-size:16px;font-weight:800;cursor:pointer;margin-top:14px}
    .primary{background:#1167d8;color:#fff}
    .secondary{background:#edf3fb;color:#17446f}
    button:disabled{opacity:.55;cursor:not-allowed}
    .result{display:none;margin-top:24px;text-align:center;border-top:1px solid #edf0f5;padding-top:24px}
    #qrcode{display:grid;place-items:center;margin:12px auto 18px}
    #qrcode canvas,#qrcode img{max-width:280px;height:auto}
    .amount{font-size:24px;font-weight:900}
    .status{font-weight:800;margin:12px 0}
    .error{color:#b42318;background:#fff0ef;padding:10px;border-radius:10px;display:none;margin-top:12px}
    .hint{font-size:13px;color:#77869a;margin-top:10px}
  </style>
</head>
<body>
<div class="wrap">
  <main class="card">
    <h1>Bayar dengan QRIS</h1>
    <p class="muted">Masukkan nominal pembayaran lalu tekan Continue.</p>

    <form id="form">
      <label for="amount">Nominal (Rp)</label>
      <input id="amount" name="amount" type="number" min="1000" max="100000000" step="1" inputmode="numeric" placeholder="Contoh: 10000" required>
      <button class="primary" id="continue" type="submit">Continue</button>
    </form>

    <div id="error" class="error"></div>

    <section class="result" id="result">
      <div class="amount" id="amountText"></div>
      <div id="qrcode"></div>
      <div class="status" id="status">Menunggu pembayaran</div>
      <button class="secondary" id="refresh" type="button">Refresh Status</button>
      <p class="hint">Tekan Refresh setelah kamu selesai melakukan pembayaran.</p>
    </section>
  </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>
<script>
const form = document.getElementById('form');
const result = document.getElementById('result');
const errorBox = document.getElementById('error');
const continueBtn = document.getElementById('continue');
const refreshBtn = document.getElementById('refresh');
const amountText = document.getElementById('amountText');
const statusText = document.getElementById('status');
const qrBox = document.getElementById('qrcode');
let orderId = null;

function showError(msg) {
  errorBox.textContent = msg;
  errorBox.style.display = msg ? 'block' : 'none';
}

function rupiah(n) {
  return new Intl.NumberFormat('id-ID', {style:'currency', currency:'IDR', maximumFractionDigits:0}).format(n);
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  showError('');
  continueBtn.disabled = true;
  continueBtn.textContent = 'Generating...';

  try {
    const amount = Number(document.getElementById('amount').value);
    const r = await fetch('api/generate.php', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({amount})
    });
    const data = await r.json();
    if (!r.ok || !data.ok) throw new Error(data.message || 'Gagal generate QRIS.');

    orderId = data.orderId;
    amountText.textContent = rupiah(data.amount);
    qrBox.innerHTML = '';
    new QRCode(qrBox, {text:data.qrContent, width:280, height:280, correctLevel:QRCode.CorrectLevel.M});
    statusText.textContent = 'Menunggu pembayaran';
    result.style.display = 'block';
  } catch (err) {
    showError(err.message);
  } finally {
    continueBtn.disabled = false;
    continueBtn.textContent = 'Continue';
  }
});

refreshBtn.addEventListener('click', async () => {
  if (!orderId) return;
  showError('');
  refreshBtn.disabled = true;
  refreshBtn.textContent = 'Checking...';

  try {
    const r = await fetch('api/status.php', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({orderId})
    });
    const data = await r.json();
    if (!r.ok || !data.ok) throw new Error(data.message || 'Gagal mengecek status.');

    statusText.textContent = data.paid ? '✓ PEMBAYARAN BERHASIL' : (data.status || 'Menunggu pembayaran');
  } catch (err) {
    showError(err.message);
  } finally {
    refreshBtn.disabled = false;
    refreshBtn.textContent = 'Refresh Status';
  }
});
</script>
</body>
</html>
