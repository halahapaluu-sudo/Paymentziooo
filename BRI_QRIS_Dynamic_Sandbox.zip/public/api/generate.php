<?php
declare(strict_types=1);
require __DIR__ . '/_bootstrap.php';

try {
    $input = json_input();
    $amount = filter_var($input['amount'] ?? null, FILTER_VALIDATE_INT);
    if ($amount === false || $amount < 1000 || $amount > 100000000) {
        respond(422, ['ok'=>false, 'message'=>'Nominal harus Rp1.000 sampai Rp100.000.000.']);
    }

    $partnerReferenceNo = 'HOLY' . date('ymdHis') . random_int(100, 999);
    $payload = [
        'partnerReferenceNo' => $partnerReferenceNo,
        'amount' => [
            'value' => number_format($amount, 2, '.', ''),
            'currency' => 'IDR',
        ],
        'merchantId' => env_required('BRI_MERCHANT_ID'),
        'terminalId' => env_required('BRI_TERMINAL_ID'),
    ];

    $token = get_access_token();
    [$http, $data] = bri_post('/snap/v1.1/qr/qr-mpm-generate', $token, $payload);

    if (empty($data['qrContent'])) {
        respond($http >= 400 ? $http : 502, [
            'ok'=>false,
            'message'=>$data['responseMessage'] ?? 'BRI tidak mengembalikan qrContent.',
            'bri'=>$data
        ]);
    }

    $orderId = bin2hex(random_bytes(12));
    save_order($orderId, [
        'orderId'=>$orderId,
        'amount'=>$amount,
        'partnerReferenceNo'=>$partnerReferenceNo,
        'referenceNo'=>$data['referenceNo'] ?? null,
        'qrContent'=>$data['qrContent'],
        'createdAt'=>date(DATE_ATOM),
        'status'=>'PENDING'
    ]);

    respond(200, [
        'ok'=>true,
        'orderId'=>$orderId,
        'amount'=>$amount,
        'qrContent'=>$data['qrContent'],
        'referenceNo'=>$data['referenceNo'] ?? null
    ]);
} catch (Throwable $e) {
    respond(500, ['ok'=>false, 'message'=>$e->getMessage()]);
}
