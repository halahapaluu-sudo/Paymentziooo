<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

function json_input(): array {
    $raw = file_get_contents('php://input') ?: '';
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function respond(int $http, array $data): never {
    http_response_code($http);
    echo json_encode($data, JSON_UNESCAPED_SLASHES);
    exit;
}

function env_required(string $key): string {
    $v = getenv($key);
    if ($v === false || trim($v) === '') {
        throw new RuntimeException("Environment variable {$key} belum diatur.");
    }
    return trim($v);
}

function base_url(): string {
    return rtrim(getenv('BRI_BASE_URL') ?: 'https://sandbox.partner.api.bri.co.id', '/');
}

function iso_timestamp(): string {
    $dt = new DateTimeImmutable('now', new DateTimeZone('Asia/Jakarta'));
    return $dt->format('Y-m-d\TH:i:s.vP');
}

function random_external_id(): string {
    return (string)random_int(100000000000, 999999999999);
}

function http_json(string $method, string $url, array $headers, ?array $body = null): array {
    $ch = curl_init($url);
    if ($ch === false) throw new RuntimeException('cURL tidak tersedia.');

    $opts = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 30,
    ];
    if ($body !== null) {
        $opts[CURLOPT_POSTFIELDS] = json_encode($body, JSON_UNESCAPED_SLASHES);
    }
    curl_setopt_array($ch, $opts);
    $raw = curl_exec($ch);
    $errno = curl_errno($ch);
    $err = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($errno) throw new RuntimeException("HTTP error: {$err}");
    $data = json_decode((string)$raw, true);
    if (!is_array($data)) throw new RuntimeException("Response BRI bukan JSON (HTTP {$code}).");
    return [$code, $data];
}

function get_access_token(): string {
    $clientId = env_required('BRI_CLIENT_ID');
    $clientSecret = env_required('BRI_CLIENT_SECRET');

    $url = base_url() . '/oauth/client_credential/accesstoken?grant_type=client_credentials';
    // Token endpoint expects application/x-www-form-urlencoded.
    $ch = curl_init($url);
    if ($ch === false) throw new RuntimeException('cURL tidak tersedia.');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
        CURLOPT_POSTFIELDS => http_build_query([
            'client_id' => $clientId,
            'client_secret' => $clientSecret,
        ]),
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 30,
    ]);
    $raw = curl_exec($ch);
    $errno = curl_errno($ch);
    $err = curl_error($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($errno) throw new RuntimeException("Token HTTP error: {$err}");
    $data = json_decode((string)$raw, true);
    if (!is_array($data)) throw new RuntimeException("Response token bukan JSON (HTTP {$http}).");
    if (empty($data['access_token'])) {
        throw new RuntimeException($data['responseMessage'] ?? 'Gagal mendapatkan access token.');
    }
    return (string)$data['access_token'];
}

function bri_signature(string $method, string $path, string $token, string $body, string $timestamp, string $secret): string {
    $minified = json_encode(json_decode($body, true), JSON_UNESCAPED_SLASHES);
    if ($minified === false) $minified = $body;
    $hash = strtolower(hash('sha256', $minified));
    $stringToSign = strtoupper($method) . ':' . $path . ':' . $token . ':' . $hash . ':' . $timestamp;
    return base64_encode(hash_hmac('sha512', $stringToSign, $secret, true));
}

function bri_post(string $path, string $token, array $payload): array {
    $secret = env_required('BRI_CLIENT_SECRET');
    $partnerId = env_required('BRI_PARTNER_ID');
    $channelId = env_required('BRI_CHANNEL_ID');

    $body = json_encode($payload, JSON_UNESCAPED_SLASHES);
    if ($body === false) throw new RuntimeException('Gagal membuat JSON request.');

    $timestamp = iso_timestamp();
    $signature = bri_signature('POST', $path, $token, $body, $timestamp, $secret);

    return http_json('POST', base_url() . $path, [
        'Authorization: Bearer ' . $token,
        'X-TIMESTAMP: ' . $timestamp,
        'X-SIGNATURE: ' . $signature,
        'Content-Type: application/json',
        'X-PARTNER-ID: ' . $partnerId,
        'CHANNEL-ID: ' . $channelId,
        'X-EXTERNAL-ID: ' . random_external_id(),
    ], $payload);
}

function order_path(string $id): string {
    $root = dirname(__DIR__, 2) . '/storage/orders';
    if (!is_dir($root)) mkdir($root, 0700, true);
    return $root . '/' . preg_replace('/[^a-zA-Z0-9_-]/', '', $id) . '.json';
}

function save_order(string $id, array $order): void {
    $path = order_path($id);
    $fp = fopen($path, 'c');
    if (!$fp) throw new RuntimeException('Storage tidak dapat dibuka.');
    flock($fp, LOCK_EX);
    ftruncate($fp, 0);
    fwrite($fp, json_encode($order, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
}

function load_order(string $id): array {
    $path = order_path($id);
    if (!is_file($path)) throw new RuntimeException('Order tidak ditemukan.');
    $data = json_decode(file_get_contents($path), true);
    if (!is_array($data)) throw new RuntimeException('Data order rusak.');
    return $data;
}
