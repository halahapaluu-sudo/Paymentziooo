<?php
declare(strict_types=1);
require __DIR__ . '/_bootstrap.php';

try {
    $input = json_input();
    $orderId = (string)($input['orderId'] ?? '');
    if (!preg_match('/^[a-f0-9]{24}$/', $orderId)) {
        respond(422, ['ok'=>false, 'message'=>'Order ID tidak valid.']);
    }

    $order = load_order($orderId);
    $token = get_access_token();

    $payload = [
        'originalReferenceNo' => (string)($order['referenceNo'] ?: $order['partnerReferenceNo']),
        'serviceCode' => '47',
        'additionalInfo' => [
            'terminalId' => env_required('BRI_TERMINAL_ID')
        ]
    ];

    [$http, $data] = bri_post('/snap/v1.1/qr/qr-mpm-query', $token, $payload);

    $code = (string)($data['responseCode'] ?? '');
    $latestStatus = (string)($data['latestTransactionStatus'] ?? '');
    // BRI v1.1 documents latestTransactionStatus = 00 as Success.
    $paid = ($latestStatus === '00');

    $order['lastInquiry'] = $data;
    $order['status'] = $paid ? 'PAID' : 'PENDING';
    save_order($orderId, $order);

    respond($http >= 400 ? $http : 200, [
        'ok'=>$http < 500,
        'paid'=>$paid,
        'status'=>$order['status'],
        'responseCode'=>$code,
        'message'=>$data['responseMessage'] ?? 'Inquiry selesai.'
    ]);
} catch (Throwable $e) {
    respond(500, ['ok'=>false, 'message'=>$e->getMessage()]);
}
